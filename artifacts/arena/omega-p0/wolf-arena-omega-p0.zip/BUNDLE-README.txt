WOLF ARENA OMEGA P0 — COMPLETE ENGINEERING HANDOFF BUNDLE
=========================================================

Source base : 061d9ffd05dc4b7f528087761755ca01468e324c
              (insidethemarginmedia-cpu/wolf-factory-home, PR #1 head, OPEN/DRAFT)
Canonical  : BLOCKED / UNAVAILABLE (private Factory 404 / git 403)
PR #701    : BLOCKED / UNAVAILABLE (REST 404, .diff http=404)
Patch      : wolf-arena-omega-p0.patch
Patch SHA  : c77dc2e884a514939331574b5d1ad8e217b13c5cf176533cbd2a120c6b00c1bb

CONTENTS
--------
wolf-arena-omega-p0.patch            unified git patch against the exact base above
WOLF-ARENA-OMEGA-P0-REPORT.md        verification report (14 defects, evidence, limits)
WOLF-ARENA-INTEGRATION.json          integration manifest (SHAs, files, tests, blockers)
WOLF-ARENA-OMEGA-P0-HASHES.sha256    SHA-256 manifest; verify: sha256sum -c <this file>
BASE-COMMIT-SHA.txt                  exact base commit and apply command
scripts/omega-p0/*.mjs               7 changed source modules (pre-effect boundary etc.)
tests/omega-p0-*.test.mjs            6 new adversarial regression suites (55 tests)
tests/fixtures/omega-p0-*.mjs        2 deterministic offline fixtures
docs/omega-p0/INTEGRATION.md         dependency + integration notes + blockers
docs/omega-p0/TEST-COMMANDS.md       exact test execution commands and observed results
test-results/*.txt                   5 captured logs (RED, GREEN, focused, full, patch apply)

HOW TO VERIFY (offline, no credentials, no network)
--------------------------------------------------
  git apply --check wolf-arena-omega-p0.patch
  git apply wolf-arena-omega-p0.patch
  node --check scripts/*.mjs scripts/omega-p0/*.mjs tests/*.mjs tests/fixtures/*.mjs
  node --test tests/omega-p0-*.test.mjs
  node --test tests/*.test.mjs
  WOLF_OMEGA_P0_FALSIFY=1 node --test tests/omega-p0-pre-effect-admission.test.mjs

Observed: 184/184 baseline; RED 5 PASS / 12 FAIL (exit 1); GREEN 17/17;
focused 55/55; full 239/239; pristine-base patch application 239/239.

SAFETY / SCOPE
--------------
EUR_SPEND=0, COST_UNKNOWN=DENY, PAID_FALLBACK=DENY, TRIAL_CREDIT=DENY,
JULES=FORBIDDEN, UNKNOWN_EXTERNAL_EFFECT=RECONCILE_ONLY.
No inference, no provider request, no sandbox, no mission, no dispatch, no merge,
no push, no publication, no new branch/PR/workflow/database/controller/Factory.
The protected UNKNOWN external effect was never replayed.

PUBLICATION: none — Loop 3 owns publication.
AUTONOMY ACCEPTANCE: NOT ACCEPTED (offline tests are not live autonomy evidence).
