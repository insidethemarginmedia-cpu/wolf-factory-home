# WOLF-ARENA-OMEGA-P0 — Verification report

Date: 2026-11-01 (UTC). Mode: RECOVER → COMPARE → REPRODUCE → REPAIR → TEST → VERIFY → PACKAGE → HANDOFF.
Classification: **INDEPENDENTLY TESTABLE SOURCE CORRECTIONS / NOT PUBLISHED / NOT PRODUCTION ACTIVATED**.
This report contains only verifiable, locally executed results. Nothing here claims real
autonomous mission completion.

---

## 0. Recovery of actual state (P0.1)

| Item | Observed result (this session) |
| --- | --- |
| Working branch | `arena/8e7c82ab-wolf-factory-home` |
| Public runtime base | `061d9ffd05dc4b7f528087761755ca01468e324c` (PR #1 head, `fix/omega-acceptance-ready-20261028`, verified by `git rev-parse HEAD` and `git ls-remote origin refs/pull/1/head`) |
| Public `main` | `3742bcc76ee2a5a8ff09897dda6611d50a4ef053` (unchanged) |
| Draft PR #1 | OPEN / DRAFT / UNMERGED, 68 files, head `061d9ffd…` (`gh pr view 1`) |
| Private Factory `donraposo1-source/project-wolf` | **BLOCKED**: `gh api repos/...` → `404 Not Found`; `git ls-remote` → `403 Write access to repository not granted` |
| Canonical branch `feat/factory-real-worker-m1-20261006` | `gh api .../git/ref/heads/...` → `404 Not Found` |
| Private Draft PR #701 | `gh api .../pulls/701` → `404`; `https://github.com/.../pull/701.diff` → `http=404` |
| Coordination issue #699 | `gh api .../issues/699` → `404 Not Found` |
| CircleCI | Not used (prohibited) |
| Baseline public suite | `node --test tests/*.test.mjs` → **184/184 PASS**, `node --check` → `ALL_MODULES_PARSE=OK` |

The last reported private canonical HEAD `ff1a8803f7b93eabe6053e061ae7e7c6e42e9cdc` and the
PR #701 HEAD therefore **could not be verified**. No canonical source file, PR #701 diff,
Loop 1–5 checkpoint body, private adapter or private test fixture was read. Prior public
checkpoints (`docs/checkpoints/omega/WOLF-OMEGA-P2-20261031.handoff.md`,
`WOLF-OMEGA-P4-20261031.handoff.md`) independently record the same 404/403 access block,
so this was not re-investigated further.

**Consequence, stated plainly:** the patch delivered here is based on the exact, clearly
identified **public** source base `061d9ffd05dc4b7f528087761755ca01468e324c`, not on the
inaccessible canonical HEAD. No private code was invented, rewritten or claimed patched.
Loop 3 must bind the delivered boundary to the real private adapters after access is granted.

Known-good Flint / CEZAR / OpenCode / Boxxkite behaviour: **preserved**. Not one existing
script, workflow, checkpoint or durable record was modified. `git diff --name-only` shows
17 files, all new. No Flint transport, OpenCode tool loop, economic control, KCT/DBOS
recovery path, checkpoint or publication authority was touched. Historical successful
execution was not conflated with current live availability (no live provider check was made).

---

## 1. Defects reproduced (RED) and corrected (GREEN)

The private PR #701 source is inaccessible, so the *reported failure classes* were
reproduced offline against an explicitly labelled reconstruction
(`tests/fixtures/omega-p0-legacy-adapter.mjs`) and against naive baseline snippets in
`tests/omega-p0-falsification.test.mjs`. This is a reproduction of the defect **class**,
not a claim that the private bytes were read.

RED command: `WOLF_OMEGA_P0_FALSIFY=1 node --test tests/omega-p0-pre-effect-admission.test.mjs`
→ **5 PASS / 12 FAIL / exit 1** (`test-results/red-before.txt`). The same 17 assertions
with the boundary wired → **17/17 PASS / exit 0** (`test-results/green-after.txt`).

| ID | Exact defect | Affected boundary / delivered function | Original failure reproduction | Minimal correction | Passing evidence |
| --- | --- | --- | --- | --- | --- |
| D01 | Omega B/C can reach external `POST /api/runs` with caller-supplied fence/economic declarations; no trusted pre-effect admission | `scripts/omega-p0/pre-effect-admission.mjs` → `admitExternalEffect`, `createPreEffectGate`, `withPreEffectAdmission` | falsification D1 (mock POST reaches boundary with `fence:"false"`, `economicAuthorized:"false"`); RED tests 4,5 | One gate wrapper immediately before the existing dispatch; ten authority facts re-read from existing ports; forbidden caller-declaration fields; exact-request binding digest | `omega-p0-pre-effect-admission.test.mjs` 17/17; falsification test 4 |
| D02 | Worker returns `COMPLETED` from a finished poll loop, mock response, process exit, generated session id or adapter assumption | `worker-evidence.mjs` → `evaluatePollingOutcome`, `verifyWorkerCompletion` | falsification D2; worker-completion test 2 (5 patterns) | Only an authenticated receipt re-read from the existing independent verifier, bound to mission/attempt/worker/job with bounded results + evidence digests, produces `COMPLETED`; all else `NOT_VERIFIED`/`FAILED` | worker-completion tests 1–6 (8/8 in file) |
| D03 | Forged/untrusted economic receipt, unknown price, nonzero cost, paid fallback, trial credit | `pre-effect-admission.mjs` → `verifyEconomicReceipt` port + `PROVIDER_COST_UNKNOWN`/`COST_NOT_ZERO`/`PAID_FALLBACK_DENIED`/`TRIAL_CREDIT_DENIED` | RED tests 4,6,7; `legacyTrustGuard` admits a fabricated admission | Re-verify ledger receipt with existing verifier; exact binding of receipt to request; `costUsd === 0`, `priceKnown === true`, no paid fallback, no trial credit | admission tests 4,6,7,8 |
| D04 | Untrusted Groq endpoint origin, unqualified account, unsupported model, unknown provider | `pre-effect-admission.mjs` → `trustedUrl`, `readEndpointRegistry`, allowlists | RED test 8 | Exact-origin/HTTPS/no-credential URL check plus existing endpoint registry provenance and policy allowlists | admission test 9 |
| D05 | Invalid/unauthorized OpenHands identity, type or execution endpoint admitted | `pre-effect-admission.mjs` → worker registry identity verification + `WORKER_ENDPOINT_UNTRUSTED` | RED test 9 | Authorized worker identity re-verified, allowed type, trusted endpoint ownership, exact endpoint match | admission test 10 |
| D06 | Jules reachable through routing, aliases or fallback selection | `worker-evidence.mjs` → `assertWorkerAllowed`, `chooseWorker`, `isForbiddenWorker`; static executable scan | RED test 10; falsification D4 (`naiveFallback(['jules','openhands']) === 'jules'`) | Normalized forbidden-token denial on every worker id/type and fallback candidate; static scan of all `.mjs`/`.yml` executable paths | admission test 11; worker-completion tests 7,8 |
| D07 | Arbitrary, empty or stale KCT fence accepted | `pre-effect-admission.mjs` → KCT claim verification + `readCurrentFencingGeneration` | RED test 11; naive baseline trusts `declaredFence` | Fence must be a positive safe integer, authenticated, equal to the current ledger generation, and equal across claim/lease/workflow | admission test 12; recovery test 4 |
| D08 | Mismatched mission/attempt/execution key/idempotency key admitted | `pre-effect-admission.mjs` → `readMission`, `verifyMission` | RED test 12 | Exact equality of all four identities with the existing mission record; terminal mission denied | admission test 13 |
| D09 | Missing/stale DBOS workflow ownership and expired/mismatched lease accepted | `pre-effect-admission.mjs` → `readWorkflowOwnership`, `readLease` | RED test 13 | Active DBOS ownership bound to exact mission/attempt/owner/fence; unexpired valid lease with matching holder and generation | admission test 14 |
| D10 | UNKNOWN external effect replayed; lost response inferred as failure; automatic retry | `pre-effect-admission.mjs` → `readExternalEffect`, `withPreEffectAdmission`, `planAfterUncertainEffect`; `recovery.mjs` → `classifyExternalWindow`, `reconcileUnknownEffect` | RED test 14; falsification D1 (one uncontrolled POST) | `UNKNOWN` → `RECONCILE_ONLY` before any effect; exactly one request, never retried; lost response → `EFFECT_UNKNOWN`, never "failed"; read-only reconciliation | admission tests 15,16; recovery tests 6,9 |
| D11 | Skill loader symlink traversal, ancestor-directory symlink escape, `..` paths, untrusted roots, unsafe manifest resolution, executable instructions | `skill-loader.mjs` → `loadSkill`, `resolveInsideRoot`, `assertNoSymlinkAncestors`, `parseManifest`, `assertInertContent`, `discoverSkills` | falsification D3 (naive `path.join` reads `SECRET OUTSIDE TRUSTED ROOT`) | Canonical realpath containment, symlink rejection at every path level including ancestors, data-only manifest keys, content inertness, no import/eval/exec | skill-loader tests 1–6 (6/6) |
| D12 | Offline tooling: weak hash, unsafe archive extraction, no version check, non-atomic install, no rollback, workspace escape, Base64 transport | `offline-install.mjs` → `verifyArtifact`, `parseArchive`, `installOfflineTool`, `verifyResumableChunks` | negative-case fixtures (symlink/hardlink/pax/device/traversal/setuid tar entries; wrong SHA; wrong version; injected staging failure) | Exact SHA-256, strict ustar parser, version verification, isolated stage + atomic rename + rollback, no network API, per-chunk resumable hashes | offline-install tests 1–8 (8/8) |
| D13 | Concurrent runner recovery / duplicate delivery / stale lease / terminal mission recreation / duplicate publication / duplicate NEXT_READY / runner destruction | `recovery.mjs` → `admitRecovery`, `consumeNextReady`, `recordPublication` | falsification D5 (non-atomic claim admits both workers); recovery test 3 | Existing atomic ledger CAS ports for delivery, recovery lease, NEXT_READY and publication; checkpoint/KCT/lease/fence/owner revalidation; fail-closed owner identity | recovery tests 1–9 (9/9) |
| D14 | Unbounded/forged admission payloads, missing authority ports treated as success | `policy.mjs` + `pre-effect-admission.mjs` → `validateRequestShape`, `readPort`, `failClosed` | RED test 2 (`COMPLETED` from an ungated request); admission test 17 | Bounded body/identifier shape, deterministic reason codes, missing port or failed read = `DENIED`, no retry | admission tests 2,17,18 |

**DEFECTS REPRODUCED: 14 classes** (12 failing RED assertions + 5 standalone
reproductions + 3 naive-baseline comparisons; overlapping).
**DEFECTS FIXED: 14 classes**, each with at least one passing adversarial regression test.

Minimum negative cases demanded by the mandate, all present: forged economic receipt ✓,
string `"false"` as authorization ✓, missing/unknown provider cost ✓, unauthorized Groq
endpoint ✓, invalid OpenHands identity ✓, fake worker completion ✓, Jules through fallback ✓,
arbitrary KCT fence ✓, empty KCT fence ✓, stale fencing generation ✓, mismatched
mission/attempt ✓, UNKNOWN external effect ✓, skill symlink escape ✓, concurrent runner
recovery ✓. Additional: crash before external request ✓, crash after request before receipt ✓,
lost response ✓, duplicate workflow delivery ✓, stale lease ✓, terminal mission recreation ✓,
duplicate publication ✓, missing external receipt ✓, runner destruction ✓, duplicate
NEXT_READY consumption ✓, ancestor symlink escape ✓, unsafe manifest ✓, executable skill
content ✓, archive symlink/hardlink/pax/traversal/setuid ✓, wrong SHA-256 ✓, version
mismatch ✓, atomic rollback ✓, workspace isolation ✓, per-chunk hash mismatch ✓.

---

## 2. Corrections: potential regressions and remaining limitations

| Correction | Potential regression | Mitigation / evidence |
| --- | --- | --- |
| Pre-effect gate | A legitimate request could be denied if a port is not bound or if policy allowlists are narrower than the existing Factory policy | All 10 facts come from injected existing ports; `normalizeConfig` defaults are test fixtures and must be replaced by existing production policy; every denial has a stable reason code; 184 pre-existing tests unchanged and passing |
| Authentic completion | A real worker whose receipt lacks one evidence field is reported `NOT_VERIFIED` instead of `COMPLETED` | Required fields are explicit and documented; fail-closed is intentional; `verifyWorkerCompletion` returns the reason |
| Jules denial | A legitimate worker whose name contains the substring `jules` is denied | Intentional: Jules is permanently forbidden; allowlist of allowed worker types is explicit |
| Skill confinement | Skills that legitimately use symlinks or executable instructions would be denied | `allowExecutable` is a Factory configuration option (never a manifest field); regular `.md`/`.json`/`.yaml` data skills load normally (tested) |
| Offline installer | Only strict ustar, regular files/directories, `package/package.json` version manifests are accepted; PAX/GNU long-name archives are denied | Deliberate fail-closed choice; deterministic reason codes; no partial install left |
| Recovery guards | Two independently delivered recovery messages with the same mission are reduced to one lease claim | Intentional single-winner semantics; duplicate delivery denied before any effect |

Remaining limitations: the real private adapters cannot be compared; the delivered ports
are integration seams that Loop 3 must bind to the existing KCT/DBOS authority; no live
provider, mission, sandbox, DBOS runtime or GitHub Actions execution was performed; no
private build/test suite was run; no provider-side economic receipt was verified.

---

## 3. Verification receipts

```
node --test tests/*.test.mjs                         239/239 PASS  exit 0   (184 baseline + 55 new)
node --test tests/omega-p0-*.test.mjs                55/55 PASS  exit 0
node --test tests/omega-p0-pre-effect-admission.test.mjs   17/17 PASS  exit 0   (GREEN)
WOLF_OMEGA_P0_FALSIFY=1 node --test tests/omega-p0-pre-effect-admission.test.mjs
                                                      5 PASS / 12 FAIL  exit 1 (RED)
node --check scripts/*.mjs scripts/omega-p0/*.mjs tests/*.mjs tests/fixtures/*.mjs
                                                      ALL_MODULES_PARSE=OK
```

Independent application on a pristine checkout of the exact base
(`git archive 061d9ffd…` → fresh git init → `git apply --check` → `git apply`):

```
APPLY_CHECK=OK   APPLY=OK   changed_files=17   ALL_MODULES_PARSE=OK
node --test tests/*.test.mjs          239/239 PASS  exit 0
node --test tests/omega-p0-*.test.mjs  55/55 PASS  exit 0
RED reproduction                       5 PASS / 12 FAIL  exit 1
```
Full log: `test-results/patch-application.txt`.

No test expectation was modified to make CI green: the 184 pre-existing tests are
byte-identical to the base (all 17 changed files are additions). The RED stage uses a
test-only falsification switch, not a changed assertion.

---

## 4. Safety policy compliance

`EUR_SPEND=0`, `COST_UNKNOWN=DENY`, `PAID_FALLBACK=DENY`, `TRIAL_CREDIT=DENY`,
`JULES=FORBIDDEN`, `UNKNOWN_EXTERNAL_EFFECT=RECONCILE_ONLY` are asserted in
`tests/omega-p0-pre-effect-admission.test.mjs` and enforced by `policy.mjs`.
The protected UNKNOWN external effect was never replayed, re-keyed, released or
terminally classified; its four durable public records remain byte-identical (the
pre-existing `tests/omega-b-preservation.test.mjs` still passes). No new branch, PR,
database, controller, scheduler, Factory, workflow or publication system was created.
PR #1 and PR #701 were not merged. Nothing was pushed to any canonical repository.

---

## 5. FINAL REPORT FORMAT

```
BASE SHA: 061d9ffd05dc4b7f528087761755ca01468e324c (verified public source base)
          canonical HEAD: BLOCKED / UNVERIFIABLE (private repo 404 / git 403)
PR #701 SHA: BLOCKED / UNAVAILABLE (REST 404, .diff http=404)
FILES CHANGED: 17 new files
  scripts/omega-p0/{policy,pre-effect-admission,worker-evidence,skill-loader,offline-install,recovery,index}.mjs
  tests/fixtures/{omega-p0-authority,omega-p0-legacy-adapter}.mjs
  tests/omega-p0-{falsification,pre-effect-admission,worker-completion,skill-loader,offline-install,recovery}.test.mjs
  docs/omega-p0/{INTEGRATION,TEST-COMMANDS}.md
DEFECTS REPRODUCED: 14 classes (RED 12 failures; 5 standalone reproductions; evidence in test-results/red-before.txt)
DEFECTS FIXED: 14 classes (55 new adversarial tests, all passing)
TESTS BEFORE: 184/184 PASS baseline; RED 5 PASS / 12 FAIL (exit 1)
TESTS AFTER: 239/239 PASS full suite (exit 0); 55/55 focused (exit 0); 17/17 GREEN (exit 0)
REGRESSION: 184 pre-existing tests unmodified and passing; pristine-base patch application 239/239 PASS
PATCH SHA-256: c77dc2e884a514939331574b5d1ad8e217b13c5cf176533cbd2a120c6b00c1bb
PACKAGE: wolf-arena-omega-p0.zip (patch, changed sources, tests, commands, results, hashes, base SHA, notes, blockers)
BLOCKERS: private Factory read access (404/403) => canonical HEAD, PR #701 HEAD, private
          adapters, Loop 1-5 checkpoint bodies and private regression/build unavailable;
          no live CI dispatch; no provider-side cost receipt; no gitleaks binary.
EXTERNAL EFFECTS: read-only GitHub REST/GraphQL metadata reads and one read-only .diff
          HTTP GET (404) only. No inference, no paid resource, no sandbox, no mission,
          no dispatch, no merge, no push, no publication, no credential use. Local temp
          directories created and removed; one local (unpushed) commit on the arena branch.
PUBLICATION: none — Loop 3 owns publication
AUTONOMY ACCEPTANCE: NOT ACCEPTED
```
